<template>
  <div>
      <div class="content-heading">
        <div>
            Pending Second Approval
        </div>
    </div>

    <div class="container-fluid">
        <!-- DATATABLE DEMO 2 -->
        <div class="card">
            <!--<div class="card-header">
                <div class="card-title">
                    Pending Second Approval
                </div>
            </div>-->
            <div class="card-body">
                <table class="table table-striped my-4 w100" id="datatable2">
                    <thead>
                        <tr>
                            <th>Account Nbr</th>
                            <th>Branch</th>
                            <th>Loan Officer</th>
                            <th>Client Name</th>
                            <th>Group Name</th>
                            <th>Amount</th>
                            <th>Created Date</th>
                            <th>Product Name</th>
                            <th>View</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

