<?php

use App\Survey;
use Illuminate\Database\Seeder;

class SurveysTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 1

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 2

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 1

        ]);


        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 1

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 2

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 4

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 4

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 4

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 3

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 3

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 3

        ]);


        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 5

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 5

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 6

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 6

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 6

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 6

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 7

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 7

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 7

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 7

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 8

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 8

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 8

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 8

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 9

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 9

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 9

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 9

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 10

        ]);

        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 10

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 10

        ]);
        Survey::create([
            'form_name' => 'Loan Approved',
            'submitted_on_date' => '2020-01-12',
            'submitted_by' => 'Robin Kalimwenjuma',
            'loan_id' => 10

        ]);
    }
}
