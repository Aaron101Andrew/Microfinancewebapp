<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoanSubtype extends Model
{
    //
}
