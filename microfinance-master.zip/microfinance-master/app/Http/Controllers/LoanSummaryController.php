<?php

namespace App\Http\Controllers;

use App\LoanSummary;
use Illuminate\Http\Request;

class LoanSummaryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\LoanSummary  $loanSummary
     * @return \Illuminate\Http\Response
     */
    public function show(LoanSummary $loanSummary)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LoanSummary  $loanSummary
     * @return \Illuminate\Http\Response
     */
    public function edit(LoanSummary $loanSummary)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LoanSummary  $loanSummary
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LoanSummary $loanSummary)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LoanSummary  $loanSummary
     * @return \Illuminate\Http\Response
     */
    public function destroy(LoanSummary $loanSummary)
    {
        //
    }
}
