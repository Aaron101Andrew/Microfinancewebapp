<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RepaymentsController extends Controller
{
    //
}
