<?php

namespace App\Http\Controllers;

use App\StandingInstruction;
use Illuminate\Http\Request;

class StandingInstructionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StandingInstruction  $standingInstruction
     * @return \Illuminate\Http\Response
     */
    public function show(StandingInstruction $standingInstruction)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StandingInstruction  $standingInstruction
     * @return \Illuminate\Http\Response
     */
    public function edit(StandingInstruction $standingInstruction)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StandingInstruction  $standingInstruction
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, StandingInstruction $standingInstruction)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StandingInstruction  $standingInstruction
     * @return \Illuminate\Http\Response
     */
    public function destroy(StandingInstruction $standingInstruction)
    {
        //
    }
}
