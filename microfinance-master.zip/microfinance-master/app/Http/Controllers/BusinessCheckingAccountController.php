<?php

namespace App\Http\Controllers;

use App\BusinessCheckingAccount;
use Illuminate\Http\Request;

class BusinessCheckingAccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\BusinessCheckingAccount  $businessCheckingAccount
     * @return \Illuminate\Http\Response
     */
    public function show(BusinessCheckingAccount $businessCheckingAccount)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\BusinessCheckingAccount  $businessCheckingAccount
     * @return \Illuminate\Http\Response
     */
    public function edit(BusinessCheckingAccount $businessCheckingAccount)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BusinessCheckingAccount  $businessCheckingAccount
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BusinessCheckingAccount $businessCheckingAccount)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\BusinessCheckingAccount  $businessCheckingAccount
     * @return \Illuminate\Http\Response
     */
    public function destroy(BusinessCheckingAccount $businessCheckingAccount)
    {
        //
    }
}
