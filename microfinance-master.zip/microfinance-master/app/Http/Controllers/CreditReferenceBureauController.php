<?php

namespace App\Http\Controllers;

use App\CreditReferenceBureau;
use Illuminate\Http\Request;

class CreditReferenceBureauController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CreditReferenceBureau  $creditReferenceBureau
     * @return \Illuminate\Http\Response
     */
    public function show(CreditReferenceBureau $creditReferenceBureau)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CreditReferenceBureau  $creditReferenceBureau
     * @return \Illuminate\Http\Response
     */
    public function edit(CreditReferenceBureau $creditReferenceBureau)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CreditReferenceBureau  $creditReferenceBureau
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CreditReferenceBureau $creditReferenceBureau)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CreditReferenceBureau  $creditReferenceBureau
     * @return \Illuminate\Http\Response
     */
    public function destroy(CreditReferenceBureau $creditReferenceBureau)
    {
        //
    }
}
